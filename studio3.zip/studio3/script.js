(function(){
"use strict";



AOS.init();
document.addEventListener("DOMContentLoaded", function(){
   setTimeout(function() {AOS.refresh(); }, 500);
   });


})();